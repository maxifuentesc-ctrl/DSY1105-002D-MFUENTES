data class Slot(
    val numero: Int,
    var estado: EstadoSlot = EstadoSlot.LIBRE
)
