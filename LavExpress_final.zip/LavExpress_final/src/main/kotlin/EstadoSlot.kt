enum class EstadoSlot {
    LIBRE,
    OCUPADO,
    EN_MANTENIMIENTO
}
