import java.time.LocalDateTime

data class Ticket(
    val id: String,
    val usuario: Usuario,
    val maquinaId: String,
    val tipoServicio: String,
    val fechaHora: LocalDateTime = LocalDateTime.now(),
    val costo: Double,
    val duracionMinutos: Int
) {
    fun mostrarResumen(): String {
        return """
        ========================================
                   TICKET DE SERVICIO
        ========================================
        ID Ticket: $id
        Cliente: ${usuario.nombre} (${usuario.telefono})
        Máquina asignada: $maquinaId
        Servicio: $tipoServicio
        Duración: $duracionMinutos min
        Costo: $$costo
        Fecha/Hora: $fechaHora
        ========================================
        """.trimIndent()
    }
}
