import java.util.Scanner

fun main() {
    val sistema = SistemaLavExpress()
    val scanner = Scanner(System.`in`)
    var salir = false

    println("==================================================")
    println("      BIENVENIDO AL SISTEMA LAVEXPRESS            ")
    println("==================================================")

    while (!salir) {
        println("\n---------------- MENÚ PRINCIPAL ----------------")
        println("1. Listar máquinas disponibles")
        println("2. Registrar nuevo cliente")
        println("3. Crear servicio / Emitir ticket")
        println("4. Ver historial de tickets")
        println("5. Estado de Slots de estacionamiento/espera")
        println("6. Salir")
        print("Seleccione una opción: ")

        val opcionStr = scanner.nextLine()
        val opcion = opcionStr.toIntOrNull()

        if (opcion == null) {
            println(" Error: Por favor, ingrese un número válido.")
            continue
        }

        when (opcion) {
            1 -> {
                sistema.listarMaquinas()
            }
            2 -> {
                println("\n--- REGISTRO DE CLIENTE ---")
                print("Nombre del cliente: ")
                val nombre = scanner.nextLine()
                print("Teléfono de contacto: ")
                val telefono = scanner.nextLine()

                if (nombre.isNotBlank() && telefono.isNotBlank()) {
                    sistema.registrarUsuario(nombre, telefono)
                } else {
                    println(" Error: Los campos no pueden estar vacíos.")
                }
            }
            3 -> {
                println("\n--- NUEVO SERVICIO ---")
                if (sistema.usuarios.isEmpty()) {
                    println(" No hay usuarios registrados. Por favor registre un cliente primero (Opción 2).")
                    continue
                }

                println("Seleccione el cliente:")
                sistema.usuarios.forEachIndexed { i, u ->
                    println("${i + 1}. ${u.nombre} (Tel: ${u.telefono})")
                }
                print("Número de cliente: ")
                val idxUsuario = scanner.nextLine().toIntOrNull()?.minus(1)

                if (idxUsuario == null || idxUsuario !in sistema.usuarios.indices) {
                    println(" Selección de cliente inválida.")
                    continue
                }
                val usuarioSeleccionado = sistema.usuarios[idxUsuario]

                sistema.listarMaquinas()
                print("Seleccione el número de la máquina: ")
                val idxMaquina = scanner.nextLine().toIntOrNull()?.minus(1)

                if (idxMaquina == null || idxMaquina !in sistema.maquinas.indices) {
                    println(" Selección de máquina inválida.")
                    continue
                }
                val maquinaSeleccionada = sistema.maquinas[idxMaquina]

                print("Ingrese la duración del ciclo en minutos (ej. 30, 45, 60): ")
                val duracion = scanner.nextLine().toIntOrNull()

                if (duracion == null || duracion <= 0) {
                    println(" Duración inválida.")
                    continue
                }

                val ticket = sistema.crearTicket(usuarioSeleccionado, maquinaSeleccionada, duracion)
                println("\n Ticket generado exitosamente:")
                println(ticket.mostrarResumen())
            }
            4 -> {
                sistema.listarTickets()
            }
            5 -> {
                println("\n--- ESTADO DE SLOTS ---")
                sistema.slots.forEach { slot ->
                    println("Slot #${slot.numero} - Estado: ${slot.estado}")
                }
            }
            6 -> {
                println("\n¡Gracias por usar LavExpress! Hasta luego.")
                salir = true
            }
            else -> {
                println(" Opción no válida. Por favor, intente de nuevo.")
            }
        }
    }
}
