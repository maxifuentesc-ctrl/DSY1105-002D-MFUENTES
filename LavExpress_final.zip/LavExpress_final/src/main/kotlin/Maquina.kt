abstract class Maquina(
    val id: String,
    val modelo: String,
    val capacidadKg: Double,
    var enFuncionamiento: Boolean = true
) {
    abstract fun iniciarCiclo(duracionMinutos: Int)
    abstract fun calcularCosto(duracionMinutos: Int): Double
}
