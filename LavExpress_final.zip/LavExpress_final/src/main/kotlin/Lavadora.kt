class Lavadora(
    id: String,
    modelo: String,
    capacidadKg: Double,
    val tipoDetergente: String = "Estándar"
) : Maquina(id, modelo, capacidadKg) {

    override fun iniciarCiclo(duracionMinutos: Int) {
        println("Lavadora $id iniciando ciclo de lavado por $duracionMinutos minutos.")
    }

    override fun calcularCosto(duracionMinutos: Int): Double {
        val tarifaBase = 5.0
        val costoPorMinuto = 0.5
        return tarifaBase + (duracionMinutos * costoPorMinuto)
    }
}
