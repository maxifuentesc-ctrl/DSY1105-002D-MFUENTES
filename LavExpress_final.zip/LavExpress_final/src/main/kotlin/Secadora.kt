class Secadora(
    id: String,
    modelo: String,
    capacidadKg: Double,
    val temperaturaMax: Int = 80
) : Maquina(id, modelo, capacidadKg) {

    override fun iniciarCiclo(duracionMinutos: Int) {
        println("Secadora $id iniciando ciclo de secado a temperatura máxima de $temperaturaMax°C por $duracionMinutos minutos.")
    }

    override fun calcularCosto(duracionMinutos: Int): Double {
        val tarifaBase = 4.0
        val costoPorMinuto = 0.6
        return tarifaBase + (duracionMinutos * costoPorMinuto)
    }
}
