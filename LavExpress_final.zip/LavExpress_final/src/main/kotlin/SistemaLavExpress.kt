import java.util.UUID

class SistemaLavExpress {
    val maquinas = mutableListOf<Maquina>()
    val usuarios = mutableListOf<Usuario>()
    val tickets = mutableListOf<Ticket>()
    val slots = mutableListOf<Slot>()

    init {
        maquinas.add(Lavadora("LAV-01", "EcoWash Pro 10", 10.0))
        maquinas.add(Lavadora("LAV-02", "SpeedClean 12", 12.0))
        maquinas.add(Secadora("SEC-01", "DryFast 800", 8.0))
        maquinas.add(Secadora("SEC-02", "DryFast 1000", 10.0))
        maquinas.add(LavasecaIndustrial("LSI-01", "Titan Combo 20", 20.0))

        for (i in 1..5) {
            slots.add(Slot(numero = i))
        }
    }

    fun listarMaquinas() {
        println("\n--- LISTA DE MÁQUINAS DISPONIBLES ---")
        if (maquinas.isEmpty()) {
            println("No hay máquinas registradas.")
            return
        }
        maquinas.forEachIndexed { idx, m ->
            val estado = if (m.enFuncionamiento) "Disponible" else "Fuera de Servicio"
            val tipo = when (m) {
                is Lavadora -> "Lavadora"
                is Secadora -> "Secadora"
                is LavasecaIndustrial -> "Lavaseca Industrial"
                else -> "Genérica"
            }
            println("${idx + 1}. [$tipo] ID: ${m.id} | Modelo: ${m.modelo} | Capacidad: ${m.capacidadKg} kg | Estado: $estado")
        }
    }

    fun registrarUsuario(nombre: String, telefono: String): Usuario {
        val id = "USR-" + (usuarios.size + 1)
        val usuario = Usuario(id, nombre, telefono)
        usuarios.add(usuario)
        println("Usuario registrado exitosamente con ID: $id")
        return usuario
    }

    fun crearTicket(usuario: Usuario, maquina: Maquina, duracion: Int): Ticket {
        val costo = maquina.calcularCosto(duracion)
        val ticketId = "TCK-" + UUID.randomUUID().toString().take(6).uppercase()
        val tipoServicio = when (maquina) {
            is Lavadora -> "Lavado"
            is Secadora -> "Secado"
            is LavasecaIndustrial -> "Lavado + Secado Industrial"
            else -> "Servicio General"
        }

        val ticket = Ticket(
            id = ticketId,
            usuario = usuario,
            maquinaId = maquina.id,
            tipoServicio = tipoServicio,
            costo = costo,
            duracionMinutos = duracion
        )
        tickets.add(ticket)
        maquina.iniciarCiclo(duracion)
        return ticket
    }

    fun listarTickets() {
        println("\n--- HISTORIAL DE TICKETS ---")
        if (tickets.isEmpty()) {
            println("No hay tickets emitidos.")
            return
        }
        tickets.forEach { ticket ->
            println(ticket.mostrarResumen())
            println()
        }
    }
}
