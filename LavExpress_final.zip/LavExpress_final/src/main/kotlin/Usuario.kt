data class Usuario(
    val id: String,
    val nombre: String,
    val telefono: String
)
