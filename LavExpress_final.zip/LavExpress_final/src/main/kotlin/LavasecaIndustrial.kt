class LavasecaIndustrial(
    id: String,
    modelo: String,
    capacidadKg: Double
) : Maquina(id, modelo, capacidadKg) {

    override fun iniciarCiclo(duracionMinutos: Int) {
        println("Lavaseca Industrial $id iniciando ciclo completo de lavado y secado por $duracionMinutos minutos.")
    }

    override fun calcularCosto(duracionMinutos: Int): Double {
        val tarifaBase = 8.0
        val costoPorMinuto = 0.8
        return tarifaBase + (duracionMinutos * costoPorMinuto)
    }
}
